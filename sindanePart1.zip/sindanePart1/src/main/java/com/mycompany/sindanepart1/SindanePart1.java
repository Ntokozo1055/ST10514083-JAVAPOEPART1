/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sindanepart1;
import java.util.Scanner;


/**
 *
 * @author Student
 */
public class SindanePart1 {

    public static void main(String[] args) {
        //declaration
        String name;
        String surname;
        String username;
        
        
        Scanner myInput= new Scanner(System.in);
        System.out.println("Please enter your Name:");
        name=myInput.next();
        System.out.println("Please enter your Surname:");
        surname=myInput.next();
        System.out.println("Please enter your Username:");
        username=myInput.next();
        
        //username validation
         while(true){
             System.out.print("enter a username:");
             username=myInput.nextLine();
             
             if(checkUserName(username)){
                 System.out.println("Username successfully captured.");
                 break;
             }
             else{
                 System.out.println("Username id not correctly formed.");
                 System.out.print("Username must contain an underscore");
             }
         }
                
    }
    
    public static boolean checkUserName(String username){
        if(username.length()<6){
            return false;
        }
        int count=0;
        int seCount=0;
        
        for(int i=0;i<username.length();i++){
            char ch=username.charAt(i);
            
            if (ch=='_'){
                count++;
            }
        }
    }
}
